package biz.r8b.twitter.basic;

public interface IfMyWebViewClient {
	public void setUrlFinished(String url);
}
