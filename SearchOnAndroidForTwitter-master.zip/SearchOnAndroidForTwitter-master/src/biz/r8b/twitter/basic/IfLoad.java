package biz.r8b.twitter.basic;

public interface IfLoad {
	public void loadMain();
}
